<div class="foot w3-container" style="height: 3vh !important;width:100%;color:#042A38;background-color:#fff;font-weight:bolder;margin:0;margin-top:1vw;bottom:0">
    <center>&nbsp;&nbsp;Designed by DGST&copy;:2024</center>
</div>