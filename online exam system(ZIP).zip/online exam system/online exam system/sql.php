<?php 
// replace *** with your database credentials
$host='localhost';
$user='root';
$project='project';
$ps='';
?>
